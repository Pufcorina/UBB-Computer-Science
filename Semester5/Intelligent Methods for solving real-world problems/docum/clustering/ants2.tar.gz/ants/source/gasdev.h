 
/* Random number generator */
/* Copyright Numerical Recipes in C */

float gasdev(long *idum);
/* End copyright Numerical Recipes in C */

