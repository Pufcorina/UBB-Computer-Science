/*  Ant-based Clustering
    Copyright (C) 2004 Julia Handl
    Email: Julia.Handl@gmx.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include <iostream>
#include "conf.h"
#include "evaluation.h"
#include <time.h>
#include "accl.h"



using namespace std;

double square(double x);
void fileoutput(char *, double *, int);
void output(clustering * cl, int size, char * name);
long idum;

int main(int argc, char ** argv) {


    idum = 4284509;
    conf c(TEST);    
    databin<float> d(&c, argv[1]);
    evaluation e(&c);

    accl * antrun;

 
    double * runtime = new double[c.evalnbr];
    double * number = new double[c.evalnbr];
    double * fmeasure = new double[c.evalnbr];
    double * variance = new double[c.evalnbr];
    double * dunn_av = new double[c.evalnbr];
    double * rand = new double[c.evalnbr];
  
  

    c.evalctr = 0;
    for (c.evalctr=0; c.evalctr<c.evalnbr; c.evalctr++) {

	databin<float> d(&c, argv[1]);
	d.permutate();	

	antrun  = new accl(&c, &d, &e);
	antrun->init();
	cout << "Evaluation No. " << c.evalctr << " with radius "  << c.radius << endl;
	time_t start = time(NULL);
	antrun->run();
	time_t end = time(NULL);

	antrun->constructclustering();
	cerr << "Evaluation initialization" << endl;
	e.init(&d, antrun->getmapping(), antrun->getclustering(), NULL);
	cerr << "Evaluation" << endl;
        number[c.evalctr] = e.clusternumber();

 	fmeasure[c.evalctr] = e.fmeasure(1);
	cout << "F-Measure = " << fmeasure[c.evalctr] << endl;
	rand[c.evalctr] = e.randindex();
	cout << "Rand Index = " << rand[c.evalctr] << endl;
	variance[c.evalctr] = e.variance();
	cout << "Variance = " << variance[c.evalctr] << endl;
	dunn_av[c.evalctr] = e.dunn_av();
	cout << "Dunn Index = " << dunn_av[c.evalctr] << endl;
	runtime[c.evalctr] = difftime(end,start);
	cout << "Runtime = " << runtime[c.evalctr] << endl;
	char name[20];
	sprintf(name, "%d.solution",c.evalctr);
	output(antrun->getclustering(),c.binsize, name);

	delete antrun;

    }


    double fmeasure_mean = 0.0, fmeasure_sd = 0.0;
    double variance_mean = 0.0, variance_sd = 0.0;
    double dunn_avmean = 0.0, dunn_avsd = 0.0;
    double rand_mean = 0.0, rand_sd = 0.0;
    double number_mean = 0.0, number_sd = 0.0;
    double time_mean = 0.0, time_sd = 0.0;
  
   
    int topctr = c.evalnbr;
    for (int i=0; i<c.evalnbr; i++) {
	fmeasure_mean += fmeasure[i];
	variance_mean += variance[i];
	dunn_avmean += dunn_av[i];
	rand_mean += rand[i];
	number_mean += number[i];
	time_mean += runtime[i];
    }

   
    fmeasure_mean /= double(c.evalnbr);
    variance_mean /= double(c.evalnbr);
    dunn_avmean /= double(c.evalnbr);
    rand_mean /= double(c.evalnbr);
    number_mean /= double(c.evalnbr);
    time_mean /= double(c.evalnbr);
  
    for (int i=0; i<c.evalnbr; i++) {

	fmeasure_sd += square(fmeasure[i]-fmeasure_mean);
	variance_sd += square(variance[i]-variance_mean);
	dunn_avsd += square(dunn_av[i]-dunn_avmean);
	rand_sd += square(rand[i]-rand_mean);
	number_sd += square(number[i]-number_mean);
	time_sd += square(runtime[i]-time_mean);
   }
    
    fmeasure_sd /= double(c.evalnbr);
    variance_sd /= double(c.evalnbr);
    dunn_avsd /= double(c.evalnbr);
    rand_sd /= double(c.evalnbr);
    number_sd /= double(c.evalnbr);
    time_sd /= double(c.evalnbr);

    fmeasure_sd = sqrt(fmeasure_sd);
    variance_sd = sqrt(variance_sd);
    dunn_avsd = sqrt(dunn_avsd);
    rand_sd = sqrt(rand_sd);
    number_sd = sqrt(number_sd);
    time_sd = sqrt(time_sd);

    fileoutput((char*)("accl_fmeasure.dat"),fmeasure,c.evalnbr);
    fileoutput((char*)("accl_variance.dat"),variance,c.evalnbr);
    fileoutput((char*)("accl_dunn_av.dat"),dunn_av,c.evalnbr);
    fileoutput((char*)("accl_rand.dat"),rand,c.evalnbr);
    fileoutput((char*)("accl_number.dat"),number,c.evalnbr);
    fileoutput((char*)("accl_time.dat"),runtime,c.evalnbr);

    ofstream summary("accl_summary.dat");
    summary << "Time: Mean = " << time_mean << ", SD = " << time_sd << endl;
    summary << "Number: Mean = " << number_mean << ", SD = " << number_sd << endl;
    summary << "FMeasure: Mean = " << fmeasure_mean << ", SD = " << fmeasure_sd << endl;
    summary << "Rand: Mean = " << rand_mean << ", SD = " << rand_sd << endl;
    summary << "Variance: Mean = " << variance_mean << ", SD = " << variance_sd << endl;
    summary << "Dunn (Average): Mean = " << dunn_avmean << ", SD = " << dunn_avsd << endl;
    summary.close();



    delete [] number;
    delete [] fmeasure;
    delete [] variance;
    delete [] dunn_av;
    delete [] rand;  
    delete [] runtime;
 
} 


double square(double x) {
    return x*x;
}


void fileoutput(char * name, double * values, int nbr) {
    ofstream out(name);
    for (int i=0; i<nbr; i++) {
	out << values[i] << endl;
    }
}


void output(clustering * cl, int size, char * name) {
  ofstream out(name);
  for (int i=0; i<size; i++) {
    out << i << " " << (*cl)[i]+1 << endl;
  }
  out << endl;
}
  

