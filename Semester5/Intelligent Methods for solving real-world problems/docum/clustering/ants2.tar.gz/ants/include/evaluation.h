/*  Ant-based Clustering
    Copyright (C) 2004 Julia Handl
    Email: Julia.Handl@gmx.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#ifndef EVALUATION_JH_2003
#define EVALUATION_JH_2003

#include "conf.h"
#include "grid.h"
#include "databin.h"
#include "clustering.h"
#include <iostream>


class evaluation {
    
    conf * par;
    databin<USED_DATA_TYPE> * bin;
    grid * env;
    clustering * clust;

    position<double> ** docindex;

   
 public:


    evaluation(conf * c);

    ~evaluation();

    void init(databin<USED_DATA_TYPE> * b, clustering * cl);
    void init(databin<USED_DATA_TYPE> * b, grid * g, clustering * cl, position<double> ** docindex);

 
    // evaluation functions used for the analysis
    // of topographic embeddings
    double square(double x);
    
    double spatialdistance(position<int> * p1, position<int> * p2, int torus);

    double spatialdistance(position<double> * p1, position<double> * p2, int torus);
  
    double number();

    double clusternumber();
    
    double fmeasure(int b);

    double randindex();

    double randindex(clustering * c1, clustering * c2, int size);

    double variance();

    double dunn_av(); 
   
};



#endif
