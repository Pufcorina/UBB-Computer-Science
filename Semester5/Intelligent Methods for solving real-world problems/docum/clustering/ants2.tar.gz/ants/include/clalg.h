/*  Ant-based Clustering
    Copyright (C) 2004 Julia Handl
    Email: Julia.Handl@gmx.de

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

/***************************************************

date: 7.4.2003

author: Julia Handl (julia.Handl@gmx.de)

description: 
implementation of general parent classes for
clustering algorithms
- class clalg
- class databin

***************************************************/

#ifndef CLALG_JH_2003
#define CLALG_JH_2003

#include "databin.h"
#include "conf.h"
#include "grid.h"
#include "clustering.h"
#include "evaluation.h"



/* 
 class clalg

 takes:
 - data collection
 
 generates:
 - grid 

 deduced classes require: 
 - (re)init
 - run
 ? interrupt ?
 ? evaluate ?
 
*/


class clalg {
 protected:
    conf * par;
    databin<USED_DATA_TYPE> * bin;
    evaluation * e;

    clustering * clust;
    grid * env;
   

 public:
    clalg(conf * par, databin<USED_DATA_TYPE> * bin, evaluation * e);
    virtual ~clalg();
    virtual void init() = 0;
    virtual void run() = 0;
    clustering * getclustering();
    grid * getmapping();
  	
};



#endif
